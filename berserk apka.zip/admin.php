<?php

	session_start();
	
	if ((!isset($_SESSION['zalogowany'])) || (!$_SESSION['rola']=="admin")) 
	{
		header('Location: index.php');
		exit();
	}

	
?>

<!DOCTYPE HTML>
<html lang ="pl">
<head>
	<meta charset="utf-8" />
	<title>Strona Logowania</title>
	<meta name="description" content="Opis strony">
	<meta names="keywords" content="slowa, kluczowe"/>
	<meta http-equiv="X-UA-Compatible" content="IE=ede,chrome=1" />
	<link href="style-boczna.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Barrio" rel="stylesheet">
</head>

<body>

	
				<div id="header">
						<a href="glowna.php"><span style="color: #c34f4f;">B</span><span style="color: white;">ER</span><span style="color: #c34f4f;">S</span><span style="color: white;">ER</span><span style="color: #c34f4f;">K</span><span style="color: white;">ER</span></a>
					<div style="clear:both;"></div>
				</div>
				<div id="menu">
				<ol>
					<li><a href="top10.php">TOP10</a></li>
					<li><a href="semestr.php">SEMESTR</a></li>
					<li><a href="punkty.php">PUNKTY</a></li>
					<li><a href="glosowanie.php">GŁOSOWANIE</a></li>
					<li><a href="proby.php">PRÓBY</a></li>
					<li><a href="semestralna.php">RYWALIZACJA</a></li>
					<li><a href="specjalne.php">SPECJALNE</a></li>
				</ol>
				</div>
	<div id="container" style="text-align:center; font-family: 'Barrio', cursive; font-size: 30px; min-height:400px;	color: #fcfcfc;">	

				<span style="text-align: center; display:block; padding-top: 30px;	font-family: 'Barrio', cursive; color:#cc3333; font-size: 40px; "> ADMIN </span>
		</br><div style="font-size:13px;"></div>
		
		
		<div  style=" min-height:150px; width: 1000px; ">
				<?php	
					//POBIERANIE DANYCH O PUNKTACH
						
					$_SESSION['czybyl']=false;	
						
					require_once "connect.php";

							$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
							if ($polaczenie->connect_errno!=0)
							{
								$_SESSION['blad'] = "blad serwera";
								header('Location: index.php');
								exit();
							}
							else{
								$polaczenie -> query ('SET NAMES utf8');
								$polaczenie -> query ('SET CHARACTER_SET utf8_unicode_ci');									
								if($result = $polaczenie->query(sprintf("SELECT nr, ile, za_co, data, imie, nazwisko FROM punkty, osoby  WHERE status = 'weryfikacja' and osoby.id=punkty.id ORDER BY data ASC LIMIT 1"))){
									if($result ->num_rows)
									{	
											$rows = $result ->fetch_object();
											$_SESSION['nr'] = $rows->nr;
											echo '<div style="padding-top:20px;">'.$rows->imie.' '.$rows->nazwisko.' '.$rows->ile.'PKT za </br>'.$rows->za_co.'</br>dnia '.$rows->data.'</div>';																				
									}	
									else header('Location: glowna.php');
								}
								$polaczenie->close();	
							}
				?>	
		
		</div>
		<div style="display:block; float:left; margin-left:350px;">
						<form action="weryfikacja.php" method="post">
							</br><input type="submit" name="tak" style="width:100px; height:50px; background-color:green; font-size:35px; font-family: 'Barrio', cursive; color:white;" value="TAK"/>	
						</form>
		</div>
				<div style="display:block; float:left; margin-left:100px;">
						<form action="weryfikacja.php" method="post">
							</br><input type="submit" name="nie" style="width:100px; height:50px; background-color:red; font-size:35px; font-family: 'Barrio', cursive; color:white;" value="NIE"/>	
						</form>
		</div>
		
		
		<div style="clear:both;"></div>
		
		
		
		
	</div>
	
	<div id="footer">
				Strona Poznańskiej Drużyny Starszo Harcerskiej Berserk
	</div>

</body>



</html>