<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany'])) 
	{
		header('Location: index.php');
		exit();
	}

	
?>

<!DOCTYPE HTML>
<html lang ="pl">
<head>
	<meta charset="utf-8" />
	<title>Strona Logowania</title>
	<meta name="description" content="Opis strony">
	<meta names="keywords" content="slowa, kluczowe"/>
	<meta http-equiv="X-UA-Compatible" content="IE=ede,chrome=1" />
	<link href="style-boczna.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Barrio" rel="stylesheet">
	
	<script type="text/javascript">
	
	function wypisz()
			{
				var liczba1 = document.getElementById("pole1").value;
				var liczba2 = document.getElementById("pole2").value;
				var napis = "";
				
				for (i=liczba1; i<=liczba2; i++)
				{
					napis = napis + i + " ";
				}
				document.getElementById("wynik").innerHTML = napis;
			}
			
	
			</script>	
</head>


<body>

	
				<div id="header">
						<a href="glowna.php"><span style="color: #c34f4f;">B</span><span style="color: white;">ER</span><span style="color: #c34f4f;">S</span><span style="color: white;">ER</span><span style="color: #c34f4f;">K</span><span style="color: white;">ER</span></a>
					<div style="clear:both;"></div>
				</div>
				<div id="menu">
				<ol>
					<li><a href="top10.php">TOP10</a></li>
					<li><a href="semestr.php">SEMESTR</a></li>
					<li><a href="punkty.php">PUNKTY</a></li>
					<li><a href="glosowanie.php">GŁOSOWANIE</a></li>
					<li><a href="proby.php">PRÓBY</a></li>
					<li><a href="semestralna.php">RYWALIZACJA</a></li>
					<li><a href="specjalne.php">SPECJALNE</a></li>
				</ol>
				</div>
	<div id="container">	
		<article id="pole">
				<span style="text-align: center; color:#cc3333; font-size: 40px; "> GŁOSOWANIE </span>
		</br><div style="font-size:13px;"></br></div>
				<?php	
					//POBIERANIE DANYCH TOP 10
								
					require_once "connect.php";

							$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
							if ($polaczenie->connect_errno!=0)
							{
								$_SESSION['blad'] = "blad serwera";
								header('Location: index.php');
								exit();
							}
							else{
								//WYBIERA TRWAJACE GLOSOWANIA
								if($result = $polaczenie->query("SELECT nr_glosowania FROM glosowanie WHERE status='trwa' ORDER BY nr_glosowanie DESC;")){
									if($result ->num_rows)
									{	

										while($rows = $result ->fetch_object()){		
												//CZY GLOSOWAL
													 if($result1 = $polaczenie->query(sprintf("SELECT sum(glosy.p1) AS p1, sum(glosy.p2) AS p2, sum(glosy.p3) AS p3, sum(glosy.p4) AS p4, sum(glosy.p5) AS p5, sum(glosy.p6) AS p6, sum(glosy.p7) AS p7, sum(glosy.p8) AS p8, sum(glosy.p9) AS p9, sum(glosy.p10) AS p10, glosowanie.temat AS temat, glosowanie.v1 AS v1, glosowanie.v2 AS v2, glosowanie.v3 AS v3, glosowanie.v4 AS v4, glosowanie.v5 AS v5, glosowanie.v6 AS v6, glosowanie.v7 AS v7, glosowanie.v8 AS v8, glosowanie.v9 AS v9, glosowanie.v10 AS v1 FROM glosy, glosowanie WHERE glosy.id='%f' and glosy.nr_glosowania = '%f' and glosy.nr_glosowania = glosowanie.nr_glosowania", $_SESSION['id'], $rows->nr_glosowania))){
														if($result1 ->num_rows)//GLOSOWAL - WYSWIETLA AKTUALNE WYNIKI GLOSOWANIA
														{																
															$rows1 = $result1 ->fetch_object();		
															if(p1!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows1->v1</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows1->p1</div><span style="clear:both;"/>';
															if(p2!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows2->v2</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows2->p2</div><span style="clear:both;"/>';
															if(p3!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows3->v3</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows3->p3</div><span style="clear:both;"/>';
															if(p4!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows4->v4</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows4->p4</div><span style="clear:both;"/>';
															if(p5!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows5->v5</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows5->p5</div><span style="clear:both;"/>';
															if(p6!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows6->v6</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows6->p6</div><span style="clear:both;"/>';
															if(p7!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows7->v7</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows7->p7</div><span style="clear:both;"/>';
															if(p8!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows8->v8</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows8->p8</div><span style="clear:both;"/>';
															if(p9!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows9->v9</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows9->p9</div><span style="clear:both;"/>';
															if(p10!=null) echo '<div style="display:block; float left; width: 600px; height:300px; background-color:red;"> $rows10->v10</div><div style="display:block; float left; width: 100px; height:300px; background-color:red;">$rows10->p10</div><span style="clear:both;"/>';
														}					
														else{//NIE GLOSOWAL - WYSWIETLA OPCJE I MOZLIWOSC ROZDZIELENIA PUNKTOW
																
																echo "nie glosowal";
															//TUTAJ BEDZIE KOD
														}
														
													}
												//END CZY GLOSOWAL
										}
										
									}
									else echo "AKTUALNIE NIE TRWA ŻADNE GŁOSOWANIE";
									
								}
								$polaczenie->close();	
							}
				?>

		</article>
	</div>
	
	<div id="footer">
				Strona Poznańskiej Drużyny Starszo Harcerskiej Berserk
	</div>

</body>



</html>