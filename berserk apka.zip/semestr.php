<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany'])) 
	{
		header('Location: index.php');
		exit();
	}

	
?>

<!DOCTYPE HTML>
<html lang ="pl">
<head>
	<meta charset="utf-8" />
	<title>Strona Logowania</title>
	<meta name="description" content="Opis strony">
	<meta names="keywords" content="slowa, kluczowe"/>
	<meta http-equiv="X-UA-Compatible" content="IE=ede,chrome=1" />
	<link href="style-boczna.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Barrio" rel="stylesheet">
</head>

<body>

	
				<div id="header">
						<a href="glowna.php"><span style="color: #c34f4f;">B</span><span style="color: white;">ER</span><span style="color: #c34f4f;">S</span><span style="color: white;">ER</span><span style="color: #c34f4f;">K</span><span style="color: white;">ER</span></a>
					<div style="clear:both;"></div>
				</div>
				<div id="menu">
				<ol>
					<li><a href="top10.php">TOP10</a></li>
					<li><a href="semestr.php">SEMESTR</a></li>
					<li><a href="punkty.php">PUNKTY</a></li>
					<li><a href="glosowanie.php">GŁOSOWANIE</a></li>
					<li><a href="proby.php">PRÓBY</a></li>
					<li><a href="semestralna.php">RYWALIZACJA</a></li>
					<li><a href="specjalne.php">SPECJALNE</a></li>
				</ol>
				</div>
	<div id="container">	
		<article id="pole">
				<span style="text-align: center; color:#cc3333; font-size: 40px; "> RANKING SEMESTRALNY </span>
		</br><div style="font-size:13px;"></br></div>
				<?php	
					//POBIERANIE DANYCH TOP 10
								
					require_once "connect.php";

							$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
							if ($polaczenie->connect_errno!=0)
							{
								$_SESSION['blad'] = "blad serwera";
								header('Location: index.php');
								exit();
							}
							else{
									
								if($result = $polaczenie->query("SELECT nick, punkty, stopien, ranga FROM osoby ORDER BY semestr ;")){
									if($result ->num_rows)
									{	
										$count = 1;
										while($rows = $result ->fetch_object()){		
											echo $count.'. '.$rows->nick.' '.$rows->stopien.' '.$rows->ranga.' '.$rows->punkty.'</br><div style="font-size:8px;"></br></div>';
											$count++;
										}
										
									}
									
								}
								$polaczenie->close();	
							}
				?>

		</article>
	</div>
	
	<div id="footer">
				Strona Poznańskiej Drużyny Starszo Harcerskiej Berserk
	</div>

</body>



</html>