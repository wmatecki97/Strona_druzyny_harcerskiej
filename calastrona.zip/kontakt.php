<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany'])) 
	{
		header('Location: index.php');
		exit();
	}

	
?>

<!DOCTYPE HTML>
<html lang ="pl">
<head>
	<meta charset="utf-8">
	<title>Strona Logowania</title>
	<meta name="description" content="Opis strony">
	<meta names="keywords" content="slowa, kluczowe"/>
	<meta http-equiv="X-UA-Compatible" content="IE=ede,chrome=1" />
	<link href="style-boczna.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Barrio" rel="stylesheet">
</head>

<body>

	<div id="header">
					<a href="admin.php"><span style="color: #c34f4f;">B</span><span style="color: white;">ER</span><span style="color: #c34f4f;">S</span><span style="color: white;">ER</span><span style="color: #c34f4f;">K</span><span style="color: white;">ER</span></a>
					<div style="clear:both;"></div>
				</div>
				<div id="menu">
				<ol>
					<li><a href="zarzadzanie.php">GŁÓWNA</a></li>
					<li><a href="top10.php">TOP10</a></li>
					<li><a href="semestr.php">SEMESTR</a></li>
					<li><a href="punkty.php">PUNKTY</a></li>
					<li><a href="glosowanie.php"> GŁOSOWANIE </a></li>
					<li><a href="proby.php">PRÓBY</a></li>					
					<li><a href="specjalne.php">SPECJALNE</a></li>
					<li><a href="kontakt.php">KONTAKT</a></li>
				</ol>
				</div>
	<div id="container">	
		<article id="pole">
				<span style="text-align: center; color:#cc3333; font-size: 40px; "> KONTAKT </span>
		</br><div style="font-size:13px;"></br></br></div>
			<div style="width:800px; margin-left:auto; margin-right: auto; text-align: left;">
				<?php	
					
								
					require_once "connect.php";

							$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
							if ($polaczenie->connect_errno!=0)
							{
								$_SESSION['blad'] = "blad serwera";
								header('Location: index.php');
								exit();
							}
							else{
								$polaczenie -> query ('SET NAMES utf8');
								$polaczenie -> query ('SET CHARACTER_SET utf8_unicode_ci');		
								if($result = $polaczenie->query("SELECT * FROM kontakt ORDER BY kolejnosc ASC;")){
									if($result ->num_rows)
									{	
											while($rows = $result ->fetch_object()){
											echo'</br></br>';											
											if(isset($rows->funkcja) && $rows->funkcja != "") echo  $rows->funkcja.': ';
											if(isset($rows->imie) && $rows->imie != "") echo  $rows->imie.' ';
											if(isset($rows->nazwisko)&& $rows->nazwisko != "") echo  $rows->nazwisko.'</br>';
											if(isset($rows->email)&& $rows->email != "") echo  $rows->email.'</br>';
											if(isset($rows->telefon)&& $rows->telefon != "") echo ' tel. '.$rows->telefon.'</br>';
											if(isset($rows->dodatkowe)&& $rows->dodatkowe != "") echo  $rows->dodatkowe.'</br>';											
										}
										
										
									}
									
								}
								$polaczenie->close();	
							}
				?>
			</div>
		</article>
	</div>
	
	<div id="footer">
				Strona Poznańskiej Drużyny Starszo Harcerskiej Berserk
	</div>

</body>



</html>