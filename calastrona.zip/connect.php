<?php

	$host = "mysql.hostinger.pl";
	$db_user = "u251061751_ber";
	$db_password = "kamuflaz1";
	$db_name = "u251061751_ber";

?>